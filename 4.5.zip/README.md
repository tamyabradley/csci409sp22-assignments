<h1>CSCI 409- Advanced Web Application
Development</h1>

<h2>Tamya Bradley</h2>

<p>
Advanced topics in the development and deployment of web-based applications.
Topics include advanced middleware programming concepts and development of dynamic websites. 
Students will write a full-scale web application as their final project.
</p>